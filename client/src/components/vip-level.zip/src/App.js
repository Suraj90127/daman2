import React from 'react';
import VIPSlider from './Components/VipSlider';

function App() {
  return (
    <div className=" overflow-hidden h-[100vh]">
      <VIPSlider />
    </div>
  );
}

export default App;
