import {useState} from 'react';
import Slider from 'react-slick';
import { AiFillExclamationCircle } from 'react-icons/ai';
import VIPCard from './Card';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import vip1 from '../Assets/1-1fca7935.png';
import vip11 from '../Assets/1-d951dc6d.png';
import vip2 from '../Assets/2-fcf77958.png';
import vip22 from '../Assets/2-5df32e87.png';
import vip3 from '../Assets/3-9cf04b7e.png';
import vip4 from '../Assets/4-a4cfd018.png';
import vip5 from '../Assets/5-89e9b349.png';
import vip6 from '../Assets/6-05959c7c.png';
import vip7 from '../Assets/7-a50aebe0.png';
import vip8 from '../Assets/8-8cbed392.png';
import vip9 from '../Assets/9-63365227.png';
import vip10 from '../Assets/10-0eaf39a0.png';
import vipBg1 from '../Assets/bg1-7ff97a99.png';
import vipBg2 from '../Assets/bg2-ee7fbf5e.png';
import vipBg3 from '../Assets/bg3-96f1cdae.png';
import vipBg4 from '../Assets/bg4-c3caf0f8.png';
import vipBg5 from '../Assets/bg5-e2132369.png';
import vipBg6 from '../Assets/bg6-8b5d1b4f.png';
import vipBg7 from '../Assets/bg7-535312da.png';
import vipBg8 from '../Assets/bg8-8bdc102c.png';
import vipBg9 from '../Assets/bg9-74d6723d.png';
import vipBg10 from '../Assets/bg10-76abb4b7.png';

const VIPSlider = () => {
  const levels = [
    { level: 1, progress: 2, maxProgress: 3000, bgColor: '#889ebe', vipImage: vip1, iconImage: vip11, bgImage: vipBg1, track: '#647a9a' },
    { level: 2, progress: 500, maxProgress: 5000, bgColor: '#e2984e', vipImage: vip2, iconImage: vip22, bgImage: vipBg2, track: '#d57c26' },
    { level: 3, progress: 2000, maxProgress: 7000, bgColor: '#ff7878', vipImage: vip3, iconImage: vip22, bgImage: vipBg3, track: '#ef5b5b' },
    { level: 4, progress: 2000, maxProgress: 200000, bgColor: '#48c7f0', vipImage: vip4, iconImage: vip22, bgImage: vipBg4, track: '#32b6e8' },
    { level: 5, progress: 2000, maxProgress: 2000000, bgColor: '#ef82d5', vipImage: vip5, iconImage: vip22, bgImage: vipBg5, track: '#ea69ca' },
    { level: 6, progress: 2000, maxProgress: 20000000, bgColor: '#46c188', vipImage: vip6, iconImage: vip22, bgImage: vipBg6, track: '#1eb18b' },
    { level: 7, progress: 2000, maxProgress: 20000000, bgColor: '#41ac46', vipImage: vip7, iconImage: vip22, bgImage: vipBg7, track: '#137b48' },
    { level: 8, progress: 2000, maxProgress: 20000000, bgColor: '#4a9ded', vipImage: vip8, iconImage: vip22, bgImage: vipBg8, track: '#215dce' },
    { level: 9, progress: 2000, maxProgress: 20000000, bgColor: '#b068f0', vipImage: vip9, iconImage: vip22, bgImage: vipBg9, track: '#742cef' },
    { level: 10, progress: 2000, maxProgress: 20000000, bgColor: '#f49c3b', vipImage: vip10, iconImage: vip22, bgImage: vipBg10, track: '#e46f1a' },
    // Add more levels with different properties as needed
  ];

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  const [showPopup, setShowPopup] = useState(false);

  const handleLogout = () => {
      console.log("Logged out");
      setShowPopup(false);
  };

  return (
    <div className="w-full px-4 py-6">
    
    <h1 className="text-center text-[11px] border border-black mb-2">VIP Level reward are settled at 2:00am on the first of every month</h1>
      <Slider {...settings}>
        {levels.map((vip) => (
          <VIPCard
            key={vip.level}
            level={vip.level}
            progress={vip.progress}
            maxProgress={vip.maxProgress}
            bgColor={vip.bgColor}
            vipImage={vip.vipImage}
            iconImage={vip.iconImage}
            bgImage={vip.bgImage}
            track={vip.track}
          />
        ))}
      </Slider>
      <button
                onClick={() => setShowPopup(true)}
                className="px-4 py-2 border border-[#4572cd] font-medium text-[#4572cd] rounded-full transition-all"
            >
                Show Logout Popup
            </button>

            {showPopup && (
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                    <div className="bg-gray-800 p-6 px-10 rounded-lg text-center">
                        <AiFillExclamationCircle className="mx-auto text-[#fb5b5b]" size={80} />
                        <h2 className="text-white font-semibold text-xl mt-4">Do you want to log out?</h2>
                        <div className="mt-6 gap-3 flex flex-col">
                            <button
                                onClick={handleLogout}
                                className="px-4 py-2 bg-[#4572cd] font-medium text-white rounded-full"
                            >
                                Confirm
                            </button>
                            <button
                                onClick={() => setShowPopup(false)}
                                className="px-4 py-2 border border-[#4572cd] font-medium text-[#4572cd] rounded-full"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}
    </div>
  );
};

export default VIPSlider;
